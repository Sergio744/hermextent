/**
 * Content script injected into MAIN world of a provider's tab.
 * Performs fetch() with the user's session cookies and streams SSE chunks
 * back to the extension via window.postMessage().
 *
 * Injected by web-llm-bridge via chrome.scripting.executeScript.
 *
 * This file contains shared setup (pre-flight requests, template substitution)
 * and shared infrastructure (Connect Protocol binary framing, standard SSE streaming).
 * Provider-specific handlers have been extracted into separate content-fetch-*.ts files.
 */

export interface ContentFetchRequest {
  type: 'WEB_LLM_FETCH';
  requestId: string;
  url: string;
  init: RequestInit;
  /**
   * Optional setup request that runs before the main fetch.
   * The JSON response is available to `urlTemplate` for variable substitution.
   * Used by providers that require session creation before streaming (e.g., Qwen).
   */
  setupRequest?: { url: string; init: RequestInit };
  /**
   * When set, the main `url` is treated as a template and `{key}` placeholders
   * are replaced with values from the setup response JSON.
   * E.g., url = "/api/completions?chat_id={id}" + setupResponse = { id: "abc" } → "/api/completions?chat_id=abc"
   */
  urlTemplate?: boolean;
  /** When set, the response uses a binary-framed protocol instead of plain SSE text. */
  binaryProtocol?:
    | 'connect-json'
    | 'gemini-chunks'
    | 'glm-intl'
    | 'deepseek'
    | 'doubao'
    | 'chatgpt'
    | 'rakuten';
  /** When true, encode the JSON body into a binary frame before sending. */
  binaryEncodeBody?: boolean;
  /** Provider-specific metadata passed from the bridge (e.g., chatgpt-web deviceId). */
  providerMetadata?: Record<string, string>;
  /** Retry attempt counter — prevents infinite tab-refresh loops (max 1). */
  retryAttempt?: number;
}

/**
 * Execute a fetch in the MAIN world and stream SSE response back.
 * This function is serialized and injected into the page context.
 */
export const mainWorldFetch = async (request: ContentFetchRequest): Promise<void> => {
  const {
    requestId,
    setupRequest,
    urlTemplate,
    binaryProtocol,
    binaryEncodeBody,
    providerMetadata: _providerMetadata,
    retryAttempt: _retryAttempt,
  } = request;
  let { url, init } = request;
  const origin = window.location.origin;
  const abortController = new AbortController();
  const onCancel = (event: MessageEvent) => {
    if (event.source !== window || event.origin !== origin) return;
    if (event.data?.type === 'WEB_LLM_CANCEL' && event.data?.requestId === requestId) abortController.abort();
  };
  window.addEventListener('message', onCancel);

  try {
    // ═══════════════════════════════════════════════════════════════════════════
    // SHARED SETUP — Optional pre-flight request and template variable substitution
    // ═══════════════════════════════════════════════════════════════════════════

    let setupData: Record<string, unknown> | undefined;
    if (setupRequest) {
      const setupResp = await fetch(setupRequest.url, {
        ...setupRequest.init,
        credentials: 'include',
        signal: abortController.signal,
      });
      if (!setupResp.ok) {
        let errorBody = '';
        try {
          errorBody = await setupResp.text();
          if (errorBody.length > 500) errorBody = errorBody.slice(0, 500);
        } catch {
          /* ignore */
        }
        const errorDetail = errorBody ? ` — ${errorBody}` : '';
        const authHint =
          setupResp.status === 401 || setupResp.status === 403
            ? ` Please visit ${origin} to verify your account is active and can use this model, then log out and log back in via Settings → Models.`
            : '';
        window.postMessage(
          {
            type: 'WEB_LLM_ERROR',
            requestId,
            error: `Setup request failed: HTTP ${setupResp.status}: ${setupResp.statusText}${errorDetail}${authHint}`,
          },
          origin,
        );
        return;
      }
      setupData = await setupResp.json();

      // Substitute template variables in main URL
      // Supports both flat (data.key) and nested (data.data.key) response structures
      if (urlTemplate && setupData) {
        const flatEntries = (obj: Record<string, unknown>, prefix = ''): [string, string][] => {
          const entries: [string, string][] = [];
          for (const [key, value] of Object.entries(obj)) {
            const fullKey = prefix ? `${prefix}.${key}` : key;
            if (typeof value === 'string' || typeof value === 'number') {
              entries.push([fullKey, String(value)]);
              // Also add without prefix for convenience (last wins)
              entries.push([key, String(value)]);
            } else if (value && typeof value === 'object' && !Array.isArray(value)) {
              entries.push(...flatEntries(value as Record<string, unknown>, fullKey));
            }
          }
          return entries;
        };
        for (const [key, value] of flatEntries(setupData)) {
          url = url.replace(`{${key}}`, value);
        }
        // Also substitute in request body if it's a string (JSON body)
        if (typeof init.body === 'string') {
          let body = init.body;
          for (const [key, value] of flatEntries(setupData)) {
            body = body.replaceAll(`{${key}}`, value);
          }
          init = { ...init, body };
        }
        // Also substitute in headers (e.g. Authorization: Bearer {access_token})
        // Only matches {word_chars} patterns to avoid corrupting headers with literal braces.
        if (init.headers && typeof init.headers === 'object' && !Array.isArray(init.headers)) {
          const templatePattern = /\{[a-zA-Z_][a-zA-Z0-9_.]*\}/;
          const headers = { ...(init.headers as Record<string, string>) };
          for (const [hKey, hVal] of Object.entries(headers)) {
            if (typeof hVal === 'string' && templatePattern.test(hVal)) {
              for (const [key, value] of flatEntries(setupData)) {
                headers[hKey] = headers[hKey].replaceAll(`{${key}}`, value);
              }
            }
          }
          init = { ...init, headers };
        }
      }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SHARED INFRASTRUCTURE — Connect Protocol + standard SSE (not provider-specific)
    // ═══════════════════════════════════════════════════════════════════════════

    // Binary frame encoding for Connect Protocol
    if (binaryProtocol === 'connect-json' && binaryEncodeBody && typeof init.body === 'string') {
      const encoder = new TextEncoder();
      const payload = encoder.encode(init.body);
      const frame = new ArrayBuffer(5 + payload.byteLength);
      const view = new DataView(frame);
      view.setUint8(0, 0x00); // flags: uncompressed
      view.setUint32(1, payload.byteLength, false); // big-endian length
      new Uint8Array(frame, 5).set(payload);
      init = { ...init, body: frame };
    }

    const response = await fetch(url, {
      ...init,
      credentials: 'include',
      signal: abortController.signal,
    });

    if (!response.ok) {
      // Read response body for diagnostic info on errors
      let errorBody = '';
      try {
        errorBody = await response.text();
        if (errorBody.length > 500) errorBody = errorBody.slice(0, 500);
      } catch {
        /* ignore */
      }
      const errorDetail = errorBody ? ` — ${errorBody}` : '';
      const authHint =
        response.status === 401 || response.status === 403
          ? ` Please visit ${origin} to verify your account is active and can use this model, then log out and log back in via Settings → Models.`
          : '';
      window.postMessage(
        {
          type: 'WEB_LLM_ERROR',
          requestId,
          error: `HTTP ${response.status}: ${response.statusText}${errorDetail}${authHint}`,
        },
        origin,
      );
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) {
      window.postMessage({ type: 'WEB_LLM_ERROR', requestId, error: 'No response body' }, origin);
      return;
    }

    if (binaryProtocol === 'connect-json') {
      // Stream binary-framed Connect Protocol response, converting frames to SSE.
      // The first chunk is inspected to detect plain-JSON error responses (byte 0 > 0x03).
      let buffer = new Uint8Array(0);
      let isFirstChunk = true;
      let _frameCount = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Append new bytes to buffer
        const merged = new Uint8Array(buffer.byteLength + value.byteLength);
        merged.set(buffer);
        merged.set(value, buffer.byteLength);
        buffer = merged;

        // First chunk: detect plain-JSON error (not binary-framed).
        // Valid Connect frame flags are 0x00-0x03; anything else is plain text.
        if (isFirstChunk && buffer.byteLength > 0 && buffer[0] > 0x03) {
          // Drain the rest of the response
          while (true) {
            const rest = await reader.read();
            if (rest.done) break;
            const m = new Uint8Array(buffer.byteLength + rest.value.byteLength);
            m.set(buffer);
            m.set(rest.value, buffer.byteLength);
            buffer = m;
          }
          const rawText = new TextDecoder().decode(buffer);
          try {
            const errObj = JSON.parse(rawText) as Record<string, unknown>;
            const errMsg = (errObj.message ??
              errObj.error ??
              errObj.code ??
              rawText.slice(0, 200)) as string;
            window.postMessage(
              { type: 'WEB_LLM_ERROR', requestId, error: `Connect error: ${errMsg}` },
              origin,
            );
          } catch {
            window.postMessage(
              {
                type: 'WEB_LLM_ERROR',
                requestId,
                error: `Connect error: ${rawText.slice(0, 500)}`,
              },
              origin,
            );
          }
          return;
        }
        isFirstChunk = false;

        // Extract complete frames: [flags:1][length:4][payload:length]
        while (buffer.byteLength >= 5) {
          const flags = buffer[0];
          const payloadLen = new DataView(
            buffer.buffer,
            buffer.byteOffset,
            buffer.byteLength,
          ).getUint32(1, false);
          const frameLen = 5 + payloadLen;
          if (buffer.byteLength < frameLen) break; // incomplete frame

          // Trailers frame (flags & 0x02) — may contain error info
          if (flags & 0x02) {
            const trailerPayload = buffer.slice(5, frameLen);
            buffer = buffer.slice(frameLen);
            try {
              const trailerStr = new TextDecoder().decode(trailerPayload);
              const trailer = JSON.parse(trailerStr) as Record<string, unknown>;
              if (trailer.code || trailer.message) {
                const errMsg = (trailer.message ??
                  trailer.code ??
                  'Unknown Connect error') as string;
                window.postMessage(
                  {
                    type: 'WEB_LLM_ERROR',
                    requestId,
                    error: `Connect error: ${errMsg} (code: ${trailer.code ?? 'none'})`,
                  },
                  origin,
                );
                return;
              }
            } catch {
              // Non-JSON trailer — ignore
            }
            continue;
          }

          const payloadBytes = buffer.slice(5, frameLen);
          buffer = buffer.slice(frameLen);

          const jsonString = new TextDecoder().decode(payloadBytes);
          _frameCount++;
          // Convert to SSE format so downstream pipeline works unchanged
          const sseChunk = `data: ${jsonString}\n\n`;
          window.postMessage({ type: 'WEB_LLM_CHUNK', requestId, chunk: sseChunk }, origin);
        }
      }

      window.postMessage({ type: 'WEB_LLM_DONE', requestId }, origin);
    } else {
      // Standard SSE text streaming
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        window.postMessage({ type: 'WEB_LLM_CHUNK', requestId, chunk }, origin);
      }

      // Flush any remaining bytes from the TextDecoder
      const finalChunk = decoder.decode();
      if (finalChunk) {
        window.postMessage({ type: 'WEB_LLM_CHUNK', requestId, chunk: finalChunk }, origin);
      }

      window.postMessage({ type: 'WEB_LLM_DONE', requestId }, origin);
    }
  } catch (err) {
    if (!abortController.signal.aborted) {
      window.postMessage(
        {
          type: 'WEB_LLM_ERROR',
          requestId,
          error: err instanceof Error ? err.message : String(err),
        },
        origin,
      );
    }
  } finally {
    window.removeEventListener('message', onCancel);
  }
};
